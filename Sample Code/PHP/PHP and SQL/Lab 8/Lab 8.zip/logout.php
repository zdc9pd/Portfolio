<?php
	//ZDC9PD, 14151501, Zac Crane
	session_start();
	session_destroy();
	header("Location: https://babbage.cs.missouri.edu/~zdc9pd/cs3380/lab8/index.php");
?>
